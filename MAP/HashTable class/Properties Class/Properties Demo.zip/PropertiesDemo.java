import java.util.Properties;
import java.io.*;
class PropertiesDemo{
	public static void main(String[] args) throws IOException,FileNotFoundException{
		Properties p = new Properties();
		FileInputStream fis = new FileInputStream("data.properties");
		p.load(fis);
		p.setProperty("userName","Mohd_Anas");
		p.setProperty("password","ansari");
		System.out.println(p.getProperty("password"));
		System.out.println(p);
		FileOutputStream fos = new FileOutputStream("data.properties");
		p.store(fos,"updated by anas");

	}
}